<?php
$host = "localhost";
$port = "3306";
$user = "TrinityFTC";
$pwd = "I_dont_know_password";
$dbname = "Trinity_Tttest";
?>